Readme for TheMarker and Ning networks (lesser2013intruder.zip)
Downloaded From: http://proj.ise.bgu.ac.il/sns
30/10/2013

Using our social network crawler, we collected the affiliation and social ties topologies of two Online Social Networks (OSNs). 
This .zip file contains anonymous versions of Ning Creator`s and Café TheMarker’s topologies.
For each of these networks, TheMarker and Ning, there are two files:
	links.csv - contains the social friendship ties among the OSN users. These links are undirected.
	groups.csv - contains the group affiliation network (the header indicates the group and user columns).
 
Snapshots of the friendship and group affiliation networks from Café TheMarker were collected during June 2011.
Snapshots of the friendship and group affiliation networks from Ning were harvested during September 2012.

More details on each of these networks can be found in our paper "Intruder or welcome friend: inferring group membership in online social networks".


The paper to be cited, included in the .zip file and also
available online (http://link.springer.com/chapter/10.1007/978-3-642-37210-0_40)


Here is a .bib entry for our manuscript
Please Cite:
Intruder or welcome friend? Inferring group membership in online social networks, 
Lesser Ofrit, Tenenboim-Chekina Lena, Rokach, Lior, and Elovici Yuval (2013).

@incollection{lesser2013intruder,
  title={Intruder or welcome friend: inferring group membership in online social networks},
  author={Lesser, Ofrit and Tenenboim-Chekina, Lena and Rokach, Lior and Elovici, Yuval},
  booktitle={Social Computing, Behavioral-Cultural Modeling and Prediction},
  pages={368--376},
  year={2013},
  publisher={Springer}
}